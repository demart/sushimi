package kz.sushimi.models.announcement;

import java.util.List;

public class Blog {
	public String Announce;
	public List<String> Banners;
	public String Created;
	public String Date;
	public String Date2;
	public String Date2String;
	public String DateString;
	
	public String Day;
	public List<String> DepartmentIds;
	public List<String> Departments;
	
	public String Id;
	public List<Image> Images;
	public String Link;
	public String NextPath;
	public String NextTitle;
	public String PrevPath;
	public String PrevTitle;
	public String Slug;
	public String SpecifyDate;
	public String Text;
	public String Title;
	public String Type;
	public String Visible;
	
}
