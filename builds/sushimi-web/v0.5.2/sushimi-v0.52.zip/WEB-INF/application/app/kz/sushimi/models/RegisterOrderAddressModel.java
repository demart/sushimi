package kz.sushimi.models;

public class RegisterOrderAddressModel {

	public String CityName;
	public String StreetName;
	public String House;
	public String Corpus;
	public String Building;
	public String Flat;
	public String Porch;
	public String DoorCode;
	public String Floor;
	public String Room;
	public String Office;
	public String Latitude;
	public String Longitude;
	
}
