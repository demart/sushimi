package kz.sushimi.models.order;

public enum CartType {
	/**
	 * Все остальные страницы
	 */
	LITE,
	
	/**
	 * Страница заказа
	 */
	EXTEND
}
