package kz.sushimi.models.order;

public class ProductItemModel {

	private Integer Key;
	private Integer Value;
	private Integer Price;
	
	public Integer getKey() {
		return Key;
	}
	public void setKey(Integer key) {
		Key = key;
	}
	public Integer getValue() {
		return Value;
	}
	public void setValue(Integer value) {
		Value = value;
	}
	public Integer getPrice() {
		return Price;
	}
	public void setPrice(Integer price) {
		Price = price;
	}
	
}
