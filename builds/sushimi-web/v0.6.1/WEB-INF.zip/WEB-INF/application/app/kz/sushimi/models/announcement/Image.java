package kz.sushimi.models.announcement;

import java.util.List;

public class Image {
	public String Blob;
	public String Description;
	public String Extension;
	public String Height;
	public String Id;
	public String Kind;
	public String Link;
	public String Name;
	public String Path;
	public String Sort;
	public String SubFolder;
	public List<Image> Thumbnails;
	public String Version;
	public String Visible;
	public String Width;
	
}