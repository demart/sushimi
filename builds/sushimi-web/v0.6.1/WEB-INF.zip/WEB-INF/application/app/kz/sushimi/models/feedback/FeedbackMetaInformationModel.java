package kz.sushimi.models.feedback;

import java.util.List;

public class FeedbackMetaInformationModel {

	public List<FeedbackTypeModel> types;
	public List<FeedbackCityModel> cities;
	
}
