package kz.sushimi.models.feedback;

public class FeedbackModel {

	public Long Id;
	public Long Uid;
	public String Created;
	public String Email;
	public String FeedbackType;
	public Integer feedbacktype_id;
	public String Fio;
	public String Phone;
	public String Text;
	public boolean Visible;
	
/*
 * "Uid": 1000000000000002,
                    "Created": "/Date(1359903636957)/",
                    "Email": null,
                    "FeedbackType": null,
                    "feedbacktype_id": 2,
                    "Fio": "Власов Игорь",
                    "Id": 2,
                    "Phone": "+7965***7252",
                    "Text": "В этом году я встретил любимую Викусю, женился и обрел прекрасного сынулю!",
                    "Visible": true
 */
	
}
