package kz.sushimi.models.feedback;

import java.util.List;

public class FeedbackTypesWrapperModel {

	public String Id;
	public String Name;
	public Boolean SocialLiked;
	public String Text;
	public Integer NextPage;
	public List<FeedbackModel> Feedbacks;
	
}
