package kz.sushimi.models.feedback;

public class FeedbackRegisterModel {
	
	public String FIO;
    public String Phone;
    public Integer CityId;
    public Integer PlaceId;
    public String ThemeId;
    public String OrderNumber;
    public String Text;
    
}
