package kz.sushimi.models.feedback;

public class FeedbackListRequestModel {

	public Integer page;
	public String type;
	
}
