package kz.sushimi.models.order;

public class PropertyModel {
	public int Id;
	public String Item;
	public String Name;
	public String Title;
	public int Type;
	public String Value;
	public int item_id; 
}
