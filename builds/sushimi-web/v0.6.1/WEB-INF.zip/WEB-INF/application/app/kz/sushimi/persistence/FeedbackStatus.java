package kz.sushimi.persistence;

public enum FeedbackStatus {
	
	NEW,
	
	ACCEPTED,
	
	DECLINED,
	
}
