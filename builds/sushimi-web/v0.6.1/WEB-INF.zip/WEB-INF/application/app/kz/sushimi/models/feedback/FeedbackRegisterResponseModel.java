package kz.sushimi.models.feedback;

public class FeedbackRegisterResponseModel {

//	{"Success":false,"Heading":"","Message":"Не удалось отправить отзыв, попробуйте чуть позже","MessageType":"warning","Timeout":0,"Data":null}
	
	public boolean Success;
	public String Heading;
	public String Message;
	public String MessageType;
	public Integer Timeout;
	public String Data;
	
}
