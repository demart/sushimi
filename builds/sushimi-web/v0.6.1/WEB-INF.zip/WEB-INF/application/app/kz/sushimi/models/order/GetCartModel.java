package kz.sushimi.models.order;

public class GetCartModel {

	public String CityId;
	public CartType Cart;
}
