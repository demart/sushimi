package kz.sushimi.console.persistence.clients;

public enum ClientPhoneSyncStatus {

	NEW,
	
	SENT,
	
	ERROR,
	
}
