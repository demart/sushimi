package kz.sushimi.console.integration.site;

public class RegisterPhoneModel {

	public String phone;
	
	public String name;
}
