package kz.sushimi.console.models;

public class ResponseWrapper {
	
	public Object data;
	public boolean success;
	public String message;
	
}
