package kz.sushimi.console.models;


public class StoreWrapper {
	
	public Object data;
	public boolean success;
	public long totalCount;
	
}
