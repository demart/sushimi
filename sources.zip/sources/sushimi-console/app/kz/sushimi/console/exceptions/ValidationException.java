package kz.sushimi.console.exceptions;

public class ValidationException extends ConsoleException {

	public ValidationException()  {
		super();
	}
	
	public ValidationException(String message)  {
		super(message);
	}
	
}
