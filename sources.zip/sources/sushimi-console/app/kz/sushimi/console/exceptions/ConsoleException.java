package kz.sushimi.console.exceptions;

public class ConsoleException extends Exception {

	public ConsoleException()  {
		super();
	}
	
	public ConsoleException(String message)  {
		super(message);
	}
	
	
}
