Ext.define('SushimiConsole.store.reports.IngredientPeriodStatStore', {
    extend: 'Ext.data.Store',
    model: 'SushimiConsole.model.reports.IngredientPeriodStatModel',
    data: [
           
	],
});