Ext.define('SushimiConsole.store.reports.OrderPeriodStatStore', {
    extend: 'Ext.data.Store',
    model: 'SushimiConsole.model.reports.OrderPeriodStatModel',
    data: [
           
	],
});