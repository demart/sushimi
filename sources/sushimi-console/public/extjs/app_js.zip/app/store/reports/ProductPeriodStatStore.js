Ext.define('SushimiConsole.store.reports.ProductPeriodStatStore', {
    extend: 'Ext.data.Store',
    model: 'SushimiConsole.model.reports.ProductPeriodStatModel',
    data: [
           
	],
});