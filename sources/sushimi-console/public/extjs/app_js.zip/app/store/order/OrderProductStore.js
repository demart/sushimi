Ext.define('SushimiConsole.store.order.OrderProductStore', {
    extend: 'Ext.data.Store',
    model: 'SushimiConsole.model.order.OrderProductModel',
    data: [
           
	],
});