Ext.define('SushimiConsole.model.WarehouseIncomeTypeModel', {
    extend: 'Ext.data.Model',
    idProperty: 'id',
    fields: [
		{ name: 'id' },
		{ name: 'name' },
	],
});