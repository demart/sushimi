Ext.define('SushimiConsole.model.CategoryTypeModel', {
    extend: 'Ext.data.Model',
    idProperty: 'id',
    fields: [
		{ name: 'id' },
		{ name: 'name' },
	],
});