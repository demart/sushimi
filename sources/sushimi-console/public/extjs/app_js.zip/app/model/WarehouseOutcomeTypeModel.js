Ext.define('SushimiConsole.model.WarehouseOutcomeTypeModel', {
    extend: 'Ext.data.Model',
    idProperty: 'id',
    fields: [
		{ name: 'id' },
		{ name: 'name' },
	],
});