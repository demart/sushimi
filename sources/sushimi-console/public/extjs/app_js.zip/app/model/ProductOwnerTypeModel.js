Ext.define('SushimiConsole.model.ProductOwnerTypeModel', {
    extend: 'Ext.data.Model',
    idProperty: 'id',
    fields: [
		{ name: 'id' },
		{ name: 'name' },
	],
});