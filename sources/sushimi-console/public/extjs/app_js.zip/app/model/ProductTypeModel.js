Ext.define('SushimiConsole.model.ProductTypeModel', {
    extend: 'Ext.data.Model',
    idProperty: 'id',
    fields: [
		{ name: 'id' },
		{ name: 'name' },
	],
});