Ext.define('SushimiConsole.view.warehouse.WarehouseController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.warehouse.warehouse',
    
});