Ext.define('SushimiConsole.controller.Main', {
    extend: 'Ext.app.Controller',
});
