package kz.aphion.sushimi.mobile.courierapp.data.models;

/**
 * 
 * Модель для получения информации о местонахождении пользователя (курьера)
 * 
 * @author artem.demidovich
 *
 */
public class UpdateGeolocationCoordinateModel extends SecuredRequestBaseModel {}
